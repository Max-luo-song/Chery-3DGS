#define foo()
foo()
