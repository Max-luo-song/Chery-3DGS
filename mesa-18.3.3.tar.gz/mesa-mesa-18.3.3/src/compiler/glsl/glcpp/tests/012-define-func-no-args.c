#define foo() bar
foo()
