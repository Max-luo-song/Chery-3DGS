#elif defined FOO
