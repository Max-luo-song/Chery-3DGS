#define foo
foo
